import UIKit
// 2. Реализуйте класс linked list, работающий только со строками. Сделайте в нём функцию поиска строки.

class LinkedListNode<T> {
    var key: T
    var next: LinkedListNode<T>?
    var previos: LinkedListNode<T>?
    
    init(_ value: T) {
        key = value
    }
}

class LinkedList<T: Equatable> {
    
    typealias Node = LinkedListNode<T>
    
    var node0: Node?
    var first: Node? { node0 }
    
    var show: String {
        var array = "["
        guard var node = node0 else {
            return array + "]"
        }
        while let next = node.next {
            array += "\(node.key), "
            node = next
        }
        array += "\(node.key)"
        return array + "]"
    }
    
    var last: Node? {
        guard var node = node0 else { return nil }
        while let next = node.next { node = next }
        return node
    }
    
    var count: Int {
        guard var node = node0 else { return 0 }
        var counter = 1
        while let next = node.next {
            counter += 1
            node = next
        }
        return counter
    }
    func add(_ value: T) {
        let new = Node(value)
        if let ex = last {
            new.previos = ex
            ex.next = new
        } else {
            node0 = new
        }
    }
    
    func insert(_ value: T) {
        if node0?.key == nil {
            node0?.key = value
        } else {
            var ex = node0
            while ex?.next != nil {
                ex = ex?.next!
            }
            let new = Node(value)
            new.key = value
            ex?.next = new
        }
    }
    
    func search(_ query: T?) -> Bool {
        while node0 != nil {
            if node0?.key == query {
                return true
            }
            node0 = node0?.next
        }
        return false
    }
}

let list = LinkedList<String>()
list.add("a")
list.count
list.add("b")
list.count
list.add("c")
list.add("d")
list.first?.key
list.add("e")
list.insert("f")
list.add("g")
list.last?.key
list.show
list.search("a")


// 3. Реализуйте класс для бинарного дерева поиска, работающий только со строками. Сделайте в нём функцию поиска.

class BinaryTree<String> {
    
    var head: String
    var left: BinaryTree?
    var right: BinaryTree?
    
    init(value: String,
         left: BinaryTree? = nil,
         right: BinaryTree? = nil) {
        head = value
        self.left = left
        self.right = right
    }
}
class BinaryTreeString<String: Comparable & CustomStringConvertible> {
    
    var searchPath: [String] = []
    
    var head: BinaryTree<String>?
    
    func node(_ value: String) {
        let node = BinaryTree(value: value)
        if let head = head {
            nextNode(head, node)
        } else {
            head = node
        }
    }
    
    func nextNode(_ value: BinaryTree<String>, _ node: BinaryTree<String>) {
        if value.head > node.head {
            if let left = value.left {
                nextNode(left, node)
            } else {
                value.left = node
            }
        } else {
            if let right = value.right {
                nextNode(right, node)
            } else {
                value.right = node
            }
        }
    }
}
extension BinaryTreeString {
 
    func traversal() {
        print("\nПрямой (preorder) обход дерева [ корень -> левый узел -> правый узел ]")
        preorder(head); print("|| F, B, A, D, C, E, G, I, H. -> bit.ly/2TMSs6t")
        print("\nЦентрированный или симметричный (inorder) обход дерева [A,B->...Z] [ левый узел -> корень -> правый узел ]")
        inorder(head); print("|| A, B, C, D, E, F, G, H, I. -> bit.ly/2X6coU0")
        print("\nОбратный (posnodeBrder) обход дерева [ левый узел -> правый узел -> корень ]")
        posorder(head); print("|| A, C, E, D, B, H, I, G, F. -> bit.ly/3ccck9o")
        print() // \n
    }
    
 
    func preorder(_ root: BinaryTree<String>?) {
        guard let _ = root else { return }
        if root.debugDescription != "nil" {
            print("\(root!.head)", terminator: " ")
            preorder(root?.left)
            preorder(root?.right)
        }
    }
    
    
    func inorder(_ root: BinaryTree<String>?) {
        if root.debugDescription != "nil" {
            inorder(root?.left)
            print("\(root!.head)", terminator: " ")
            inorder(root?.right)
        }
    }
    

    func posorder(_ root: BinaryTree<String>?) {
        if root.debugDescription != "nil" {
            posorder(root?.left)
            posorder(root?.right)
            print("\(root!.head)", terminator: " ")
        }
    }
}
extension BinaryTreeString {
    
    func search(_ query: String) {
        finder(head, query)
    }
    
    private func finder(_ head: BinaryTree<String>?, _ query: String) {
        
        guard let root = head else {
            print("x x x Узел '\(query)' НЕ НАЙДЕН! x x x")
            return
        }
        
        searchPath.append(root.head)
        print("\(searchPath) узел '\(root.head)' -> Ищу: '\(query)'")
        
        if query > root.head {
            finder(root.right, query)
        } else if query < root.head {
            finder(root.left, query)
        } else {
            print("= = = Узел '\(root.head)' найден = = =\n")
            searchPath.removeAll()
        }
    }
}
let tree = BinaryTreeString<String>()

tree.node("F")
tree.node("B")
tree.node("A")
tree.node("D")
tree.node("C")
tree.node("E")
tree.node("G")
tree.node("I")
tree.node("H")
tree.traversal()


tree.search("C")

tree.search("N")




class DijkstraNode<T: Equatable & Hashable>: Equatable, Hashable {
    var value: T
    var edges: [DijkstraEdge<T>] = []
    var visited: Bool = false
    var weight: Double = Double(Int.max)
    var prev: DijkstraNode<T>?
    
    init(_ value: T) { self.value = value }
    
    var hashValue: Int { get { value.hashValue } }
    func hash(into hasher: inout Hasher) { }
}

func == <T: Equatable> (lhs: DijkstraNode<T>, rhs: DijkstraNode<T>) -> Bool {
    guard lhs.value == rhs.value else { return false }
    return true
}

class DijkstraEdge<T: Equatable & Hashable>: Equatable, Hashable {
    var from: DijkstraNode<T>
    var to: DijkstraNode<T>
    var timeStr: String?
    var weight: Double
    

    init(from: DijkstraNode<T>, to: DijkstraNode<T>, weight: Double) {
        self.weight = weight
        self.from = from
        self.to = to
        from.edges.append(self)
        timeStr = traveltime(weight)
    }
    
    var hashValue: Int {
        get { "\(from.value) -> \(to.value)".hashValue }
    }
    func hash(into hasher: inout Hasher) { }
}

func == <T: Equatable> (lhs: DijkstraEdge<T>, rhs: DijkstraEdge<T>) -> Bool {
    guard lhs.from.value == rhs.from.value else { return false }
    guard lhs.to.value == rhs.to.value else { return false }
    return true
}

class DijkstraGraph<T: Hashable & Equatable> {
    var nodes: [DijkstraNode<T>]
    
    init(nodes: [DijkstraNode<T>]) { self.nodes = nodes }
    
    static func path(graph: DijkstraGraph<T>, from: DijkstraNode<T>, to: DijkstraNode<T>) {
        
        var unvisited = Set<DijkstraNode<T>>(graph.nodes)
        
        from.weight = 0.0
        
 
        var current: DijkstraNode<T> = from
 
        while (to.visited == false) {
            
            for edge in current.edges.filter({ edge -> Bool in
                return edge.to.visited == false
            }) {
  
                let tempDist = current.weight + edge.weight
                
                if edge.to.weight > tempDist {
                    edge.to.weight = tempDist
                    edge.to.prev = current
                }
            }
            
            current.visited = true
            
            unvisited.remove(current)
            
            if let new = unvisited.sorted(by: { (A, B) -> Bool in
                A.weight < B.weight
            }).first {
                current = new
            } else { break }
        }
        DijkstraGraph.printPath(node: to)
    }
    
    static func printPath(node: DijkstraNode<T>) {
        if let previous = node.prev {
            DijkstraGraph.printPath(node: previous)
        } else {
            print("\nПоиск пути по алгоритму Дейкстры:")
        }
        print("\(node.prev?.value == nil ? "" : "-> ")«\(node.value)» [\(traveltime(node.weight))]", terminator: " ")
    }
}

func traveltime(_ value: Double) -> String {
    let date = Date(timeIntervalSinceNow:(value * 60.0))
    let dateFormatter = DateFormatter()
    dateFormatter.dateStyle = .none
    dateFormatter.timeStyle = .short
    dateFormatter.locale = Locale(identifier: "gb_GB")
    return dateFormatter.string(from: date)
}


let nodeA = DijkstraNode("A")
let nodeB = DijkstraNode("B")
let nodeC = DijkstraNode("C")
let nodeD = DijkstraNode("D")
let nodeE = DijkstraNode("E")


let edgeAB = DijkstraEdge(from: nodeA, to: nodeB, weight: 3)
let edgeBA = DijkstraEdge(from: nodeB, to: nodeA, weight: 3)
let edgeAC = DijkstraEdge(from: nodeA, to: nodeC, weight: 1)
let edgeCA = DijkstraEdge(from: nodeC, to: nodeA, weight: 1)
let edgeBC = DijkstraEdge(from: nodeB, to: nodeC, weight: 1)
let edgeCB = DijkstraEdge(from: nodeC, to: nodeB, weight: 1)
let edgeBD = DijkstraEdge(from: nodeB, to: nodeD, weight: 2)
let edgeDB = DijkstraEdge(from: nodeD, to: nodeB, weight: 2)
let edgeDE = DijkstraEdge(from: nodeD, to: nodeE, weight: 1)
let edgeED = DijkstraEdge(from: nodeE, to: nodeD, weight: 1)
let edgeCE = DijkstraEdge(from: nodeC, to: nodeE, weight: 8)
let edgeEC = DijkstraEdge(from: nodeE, to: nodeC, weight: 8)
let graph = DijkstraGraph(nodes: [nodeA, nodeB, nodeC, nodeD, nodeE])
DijkstraGraph.path(graph: graph, from: nodeA, to: nodeE)



class BFSNode<T> {
    let current: T
    var neighbor: BFSNode<T>?
    
    init(_ current: T, neighbor: BFSNode<T>? = nil ) {
        self.current = current
        self.neighbor = neighbor
    }
}

class BFSQueue<T> {
    
    var current: BFSNode<T>?
    
    var last: BFSNode<T>? {
        if var node = current {
            while let next = node.neighbor { node = next }
            return node
        } else {
            return nil
        }
    }
    
    var count: Int {
        if var node = current {
            var count: Int = 1
            while let next = node.neighbor {
                count += 1
                node = next
            }
            return count
        } else {
            return 0
        }
    }
    
    var isEmpty: Bool { current == nil }
    
    func append(_ node: T) {
        let node = BFSNode<T>(node)
        if let prev = last {
            prev.neighbor = node
        } else {
            current = node
        }
    }
    
    func removeFirst() -> T? {
        let first = current
        current = current?.neighbor
        return first?.current
    }
}

struct Node<T>: CustomStringConvertible, Hashable where T: Hashable {
    let value: T
    let index: Int
    var description: String { "\(value)" }
}

struct QueueBFS<T> {
    var queue = BFSQueue<T>()
    var isEmpty: Bool { queue.isEmpty }
    mutating func enqueue(_ node: T) { queue.append(node) }
    mutating func dequeue() -> T? { queue.removeFirst() }
}

struct BFSEdge<T>: CustomStringConvertible, Hashable where T: Hashable {
    let from: Node<T>
    let to: Node<T>
    let weight: Double?
    let time: String
    
    var description: String { "«\(from)» -[\(time)]-> «\(to)»" }
}

class EdgeList<T> where T: Hashable {
    let node: Node<T>
    var edges: [BFSEdge<T>] = []
    
    init(_ node: Node<T>) {
        self.node = node
    }
    
    func append(_ edge: BFSEdge<T>) {
        edges.append(edge)
    }
}

protocol BFSGraph {
    associatedtype Element: Hashable
    func edgesFrom(_ : Node<Element>) -> [BFSEdge<Element>]
}
enum Visited<Element: Hashable> {
    case node
    case edge(BFSEdge<Element>)
}

class BFS<T> where T: Hashable {
    
    var edgeList: [EdgeList<T>] = []
    private var effort = 0.0
    
    func directed(from: Node<T>, to: Node<T>, weight: Double?){
        if from.index < edgeList.count {
            effort += weight!
            let edge = BFSEdge<T>(from: from, to: to, weight: weight, time: traveltime(effort))
            edgeList[from.index].append(edge)
        } else {
            return
        }
    }
    
    func undirected(nodes: (Node<T>, Node<T>), weight: Double?) {
        let (from, to) = nodes
        if from.index < edgeList.count && to.index < edgeList.count {
            directed(from: from, to: to, weight: weight)
            directed(from: to, to: from, weight: weight)
        } else {
            return
        }
    }
    
    func breadthFirstSearch(from: Node<Element>, to: Node<Element>) -> [BFSEdge<Element>] {
        
        var queue: QueueBFS<Node<Element>> = QueueBFS()
        queue.enqueue(from)
        
        var visits: [Node<Element>: Visited<Element>] = [from: .node]
        
        while let visited = queue.dequeue() {
            if visited == to {
                var route: [BFSEdge<Element>] = []
                var node = to
                while let visit = visits[node],
                      case .edge(let edge) = visit {
                    route = [edge] + route
                    node = edge.from
                }
                return route
            }
            let neightbourEdges = edgesFrom(visited)
            
            for edge in neightbourEdges {
                if visits[edge.to] == nil {
                    queue.enqueue(edge.to)
                    visits[edge.to] = .edge(edge)
                }
            }
        }
        return []
    }
}

extension BFS: BFSGraph {
    
    func node(_ value: T) -> Node<T> {
        
        let nodes: [EdgeList<T>] = edgeList.filter { $0.node.value == value }
        
        if nodes.count == 0 {
            let node = Node<T>(value: value, index: edgeList.count)
            let newEdge = EdgeList<T>(node)
            edgeList.append(newEdge)
            return node
        } else {
            return nodes.last!.node
        }
    }
    
    func edge(from: Node<T>, to: Node<T>, weight: Double?) {
        undirected(nodes: (from, to), weight: weight)
    }
    
    func edgesFrom(_ node: Node<T>) -> [BFSEdge<T>] {
        node.index < edgeList.count ? edgeList[node.index].edges : []
    }
}

let BFSgraph = BFS<String>()
let BFS_A = BFSgraph.node("A")
let BFS_B = BFSgraph.node("B")
let BFS_C = BFSgraph.node("C")
let BFS_D = BFSgraph.node("D")
let BFS_E = BFSgraph.node("E")

BFSgraph.edge(from: BFS_A, to: BFS_B, weight: 3)
BFSgraph.edge(from: BFS_A, to: BFS_C, weight: 5)
BFSgraph.edge(from: BFS_C, to: BFS_D, weight: 1)
BFSgraph.edge(from: BFS_A, to: BFS_D, weight: 6)
BFSgraph.edge(from: BFS_C, to: BFS_E, weight: 1)
print("\n\nПоиск в ширину (BFS):")
print(BFSgraph.breadthFirstSearch(from: BFS_B, to: BFS_E))



struct DFSNode<T: Hashable>: Hashable, CustomStringConvertible {
    var value: T
    var weight: Double
    var time: String
    var description: String { "\(value) \(time)" }
}

class DFS<T: Hashable>: DFSGraph {
    
    var edgesDict: [DFSNode<T>: [DFSEdge<T>]] = [:]
    
    func directed(from: DFSNode<T>, to: DFSNode<T>, weight: Double?) {
        let edge = DFSEdge(from: from, to: to, weight: weight)
        edgesDict[from]?.append(edge)
    }
    
    func undirected(nodes: (DFSNode<T>, DFSNode<T>), weight: Double?) {
        let (from, to) = nodes
        directed(from: from, to: to, weight: weight)
        directed(from: to, to: from, weight: weight)
    }
    
    func node(_ value: T, weight: Double) -> DFSNode<T> {
        let node = DFSNode(value: value, weight: weight, time: traveltime(Double(edgesDict.count) + weight))
        
        if edgesDict[node] == nil {
            edgesDict[node] = []
        }
        return node
    }
    
    func edge(from: DFSNode<T>, to: DFSNode<T>, weight: Double? = 0) {
        undirected(nodes: (from, to), weight: weight)
    }
    
    func weight(from: DFSNode<T>, to: DFSNode<T>) -> Double? {
        guard let edges = edgesDict[from] else { return nil }
        for edge in edges {
            if edge.to == to {
                edge.weight
            }
        }
        return nil
    }
    
    func edges(from: DFSNode<T>) -> [DFSEdge<T>]? {
        return edgesDict[from]
    }
}

struct DFSEdge<T: Hashable> {
    var from: DFSNode<T>
    var to: DFSNode<T>
    let weight: Double?
}

protocol DFSGraph {
    associatedtype Element: Hashable
    
    func node(_ data: Element, weight: Double) -> DFSNode<Element>
    func edge(from: DFSNode<Element>, to: DFSNode<Element>, weight: Double?)
    func weight(from: DFSNode<Element>, to: DFSNode<Element>) -> Double?
    func edges(from: DFSNode<Element>) -> [DFSEdge<Element>]?
}

struct DFSReturn<T>: CustomStringConvertible {
    var array: [T] = []
    mutating func push(_ element: T) { array.append(element) }
    mutating func peek() -> T? { array.last }
    mutating func pop() -> T? { array.popLast() }
    
    var description: String {
        let top = "-----------\n"
        let bottom = "\n-----------\n"
        return top + array.map{"\($0)"}.joined(separator: "\n") + bottom
    }
}

func depthFirstSearch(graph: DFS<String>, from: DFSNode<String>, to: DFSNode<String>) -> DFSReturn<DFSNode<String>> {
    var visited = Set<DFSNode<String>>()
    var output = DFSReturn<DFSNode<String>>()
    
    output.push(from)
    visited.insert(from)
    
    while let node = output.peek(), node != to {
        guard let neighbours = graph.edges(from: node), neighbours.count > 0 else {
            continue
        }
        
        for edge in neighbours {
            if !visited.contains(edge.to) {
                visited.insert(edge.to)
                output.push(edge.to)
                print(output.description)
                if output.array.last == to {
                    print("End!")
                    break
                }
                break
            }
        }
    }
    return output
}

let DFSgraph = DFS<String>()
let DFS_S = DFSgraph.node("S", weight: 1)
let DFS_A = DFSgraph.node("A", weight: 2)
let DFS_B = DFSgraph.node("B", weight: 3)
let DFS_C = DFSgraph.node("C", weight: 4)
let DFS_D = DFSgraph.node("D", weight: 5)
let DFS_F = DFSgraph.node("F", weight: 6)
let DFS_G = DFSgraph.node("G", weight: 7)
let DFS_E = DFSgraph.node("E", weight: 8)

DFSgraph.edge(from: DFS_S, to: DFS_A)
DFSgraph.edge(from: DFS_A, to: DFS_B)
DFSgraph.edge(from: DFS_A, to: DFS_D)
DFSgraph.edge(from: DFS_A, to: DFS_C)
DFSgraph.edge(from: DFS_B, to: DFS_D)
DFSgraph.edge(from: DFS_D, to: DFS_G)
DFSgraph.edge(from: DFS_D, to: DFS_F)
DFSgraph.edge(from: DFS_F, to: DFS_E)

print("\n\nПоиск в глубину (DFS):")
depthFirstSearch(graph: DFSgraph, from: DFS_S, to: DFS_G)


protocol AStarGraph {
    associatedtype Element: Hashable
    
    func node(_ value: Element) -> AStarNode<Element>
    func edge(from: AStarNode<Element>, to: AStarNode<Element>, weight: Double?)
    func edges(from: AStarNode<Element>) -> [AStarEdge<Element>]?
}

class AStar<T: Hashable>: AStarGraph {
    
    var edgesDict: [AStarNode<T>: [AStarEdge<T>]] = [:]
    var effort = 0.0
    
    func directed(from: AStarNode<T>, to: AStarNode<T>, weight: Double?) {
        let edge = AStarEdge(from: from, to: to, weight: weight)
        edgesDict[from]?.append(edge)
        effort = Double(edgesDict.count)
    }
    
    func undirected(nodes: (AStarNode<T>, AStarNode<T>), weight: Double?) {
        let (from, to) = nodes
        directed(from: from, to: to, weight: weight)
        directed(from: to, to: from, weight: weight)
    }
    
    func node(_ value: T) -> AStarNode<T> {
        let node = AStarNode(value: value)
        
        if edgesDict[node] == nil {
            edgesDict[node] = []
        }
        return node
    }
    
    func edge(from: AStarNode<T>, to: AStarNode<T>, weight: Double?) {
        undirected(nodes: (from, to), weight: weight)
    }
    
    func edges(from: AStarNode<T>) -> [AStarEdge<T>]? {
        return edgesDict[from]
    }
}

struct AStarEdge<T: Hashable>: Hashable {
    var from: AStarNode<T>
    var to: AStarNode<T>
    let weight: Double?
    
   
    var hashValue: Int {
        "\(from)\(to)\(weight ?? 0)".hashValue
    }
    static func ==(lhs: AStarEdge<T>, rhs: AStarEdge<T>) -> Bool {
        lhs.from == rhs.from &&
        lhs.to == rhs.to &&
        lhs.weight == rhs.weight
    }
    func hash(into hasher: inout Hasher) { }
}

struct AStarNode<T: Hashable> : Hashable, CustomStringConvertible {
    var value: T
    
  
    var hashValue: Int { "\(value)".hashValue }
    static func ==(lhs: AStarNode, rhs: AStarNode) -> Bool {
        lhs.value == rhs.value
    }
    func hash(into hasher: inout Hasher) { }
    var description: String {
        return "\(value)" + " \(traveltime(1.0))"
    }
}

func aStarSearch<T>(from: AStarNode<T>, to: AStarNode<T>, graph: AStar<T>, heuristic: [T:Double]) {
    print("\nПоиск алгоритмом A* (AStar)")
    let path = aStar(from: from, to: to, graph: graph, heuristic: heuristic)
    print(path)
}

func aStar<T>(from: AStarNode<T>, to: AStarNode<T>, graph: AStar<T>, heuristic: [T:Double]) -> DFSReturn<AStarNode<T>> {
    var visited = Set<AStarNode<T>>()
    var stack = DFSReturn<AStarNode<T>>()
    
    visited.insert(from)
    stack.push(from)
    
    while let node = stack.peek(), node != to {
        guard let neighbours = graph.edges(from: node), neighbours.count > 0 else {
            continue
        }
        
        var edges = [(node: AStarNode<T>, f: Double)]()
        
        for edge in neighbours {
            let current = edge.to
            if !visited.contains(current) {
                visited.insert(current)
                edges.append((node: current, f: funcAStar(g: edge.weight, h: heuristic[current.value])))
            }
        }
        if let minF = edges.sorted(by: {$0.f < $1.f}).first {
            stack.push(minF.node)
        }
    }
    return stack
}


func funcAStar(g: Double?, h: Double?) -> Double {
    return (g ?? 0) + (h ?? 0)
}

var heuristicTable: [String: Double] {
    return ["A": 366,
            "B": 253,
            "C": 74,
            "D": 380,
            "E": 178,
            "F": 0,
            "G": 98,
            "H": 160,
            "I": 193]
}

let astar = AStar<String>()
let AStar_A = astar.node("A")
let AStar_B = astar.node("B")
let AStar_C = astar.node("C")
let AStar_D = astar.node("D")
let AStar_E = astar.node("E")
let AStar_F = astar.node("F")
let AStar_G = astar.node("G")
let AStar_H = astar.node("H")
let AStar_I = astar.node("I")

astar.edge(from: AStar_A, to: AStar_C, weight: 75)
astar.edge(from: AStar_C, to: AStar_D, weight: 71)
astar.edge(from: AStar_D, to: AStar_B, weight: 151)
astar.edge(from: AStar_D, to: AStar_E, weight: 100)
astar.edge(from: AStar_A, to: AStar_B, weight: 140)
astar.edge(from: AStar_B, to: AStar_E, weight: 99)
astar.edge(from: AStar_B, to: AStar_I, weight: 80)
astar.edge(from: AStar_I, to: AStar_G, weight: 97)
astar.edge(from: AStar_H, to: AStar_I, weight: 146)
astar.edge(from: AStar_H, to: AStar_G, weight: 138)
astar.edge(from: AStar_G, to: AStar_F, weight: 101)
astar.edge(from: AStar_E, to: AStar_F, weight: 211)

aStarSearch(from: AStar_A, to: AStar_F, graph: astar, heuristic: heuristicTable)

// 5. Реализуйте функцию сортировки массива ещё двумя способами, кроме рассказанных на уроке.
extension Array where Element: Comparable {
    func bubbleSort() -> [Element] {
        var array = self
        for i in (0..<array.count-1).reversed() {
            for j in (1..<(i+1)) {
                if array[j-1] > array[j] {
                    let temp = array[j-1]
                    array[j-1] = array[j]
                    array[j] = temp
                }
            }
        }
        return array
    }
    func selectionSort() -> [Element] {
        var array = self
        for i in array.indices {
            var minIndex = i
            for j in i+1..<array.count {
                if array[j] < array[minIndex] {
                    minIndex = j
                }
            }
            let temp = array[minIndex]
            array[minIndex] = array[i]
            array[i] = temp
        }
        return array
    }
}

[0,7,5,3,9,10].bubbleSort()
[1,0,8,7,5,3,9,10,19].selectionSort()


extension Array where Element: Comparable {
    func insertionSort() -> [Element] {
        var array = self
        for x in 1..<array.count {
            var y = x
            while y > 0 && array[y] < array[y - 1] {
                array.swapAt(y - 1, y)
                y -= 1
            }
        }
        return array
    }
}

let array = [1,0,8,7,5,3,9,10,19].insertionSort()

func BucketSort(list: inout [Int], max: Int) {
    var count = Array<Bool>(repeating: false, count: max + 1)
    
    for i in list { count[i] = true }
    
    var index = 0
    for i in count.indices {
        if count[i] {
            list[index] = i
            index += 1
        }
    }
}
var BS = [7,1,9,5,2,0]
BucketSort(list: &BS, max: BS.max()!)
func mergeSort<T: Comparable>(_ array: [T]) -> [T] {
    guard array.count > 1 else { return array }
    let midIndex = array.count / 2
    let leftArr = mergeSort(Array(array[0..<midIndex]))
    let rightArr = mergeSort(Array(array[midIndex..<array.count]))
    return merge(lPile: leftArr, rPile: rightArr)
}
func merge<T: Comparable>(lPile: [T], rPile: [T]) -> [T] {
    var lIndex = 0
    var rIndex = 0
    var ordered = [T]()
    if ordered.capacity < lPile.count + rPile.count {
        ordered.reserveCapacity(lPile.count + rPile.count)
    }
    
    while true {
        guard lIndex < lPile.endIndex else {
            ordered.append(contentsOf: rPile[rIndex..<rPile.endIndex])
            break
        }
        guard rIndex < rPile.endIndex else {
            ordered.append(contentsOf: lPile[lIndex..<lPile.endIndex])
            break
        }
        
        if lPile[lIndex] < rPile[rIndex] {
            ordered.append(lPile[lIndex])
            lIndex += 1
        } else {
            ordered.append(rPile[rIndex])
            rIndex += 1
        }
    }
    return ordered
}

let array1 = [2, 1, 5, 4, 3]
let sortedArray = mergeSort(array1)
let array2 = ["D", "E", "A", "C", "B"]
let sortedArray2 = mergeSort(array2)
